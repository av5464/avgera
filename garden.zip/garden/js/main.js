$(function(){
	$('#plant-one').hover(function(){
		$('#big-img').attr('src', $(this).attr('alt'));
	});
	$('#plant-one').hover(function(){
		$(this).attr('src','img/exhibition/icon/1.png');
		$(this).css('cursor', 'pointer');
	}, function(){
		$(this).attr('src','img/exhibition/icon/2.png');
	});
});

$(function(){
	$('#plant-two').hover(function(){
		$('#big-img').attr('src', $(this).attr('alt'));
	});
	$('#plant-two').hover(function(){
		$(this).attr('src','img/exhibition/icon/1.png');
		$(this).css('cursor', 'pointer');
	}, function(){
		$(this).attr('src','img/exhibition/icon/2.png');
	});
});

$(function(){
	$('#plant-three').hover(function(){
		$('#big-img').attr('src', $(this).attr('alt'));
	});
	$('#plant-three').hover(function(){
		$(this).attr('src','img/exhibition/icon/1.png');
		$(this).css('cursor', 'pointer');
	}, function(){
		$(this).attr('src','img/exhibition/icon/2.png');
	});
});

$(function(){
	$('#plant-four').hover(function(){
		$('#big-img').attr('src', $(this).attr('alt'));
	});
	$('#plant-four').hover(function(){
		$(this).attr('src','img/exhibition/icon/1.png');
		$(this).css('cursor', 'pointer');
	}, function(){
		$(this).attr('src','img/exhibition/icon/2.png');
	});
});